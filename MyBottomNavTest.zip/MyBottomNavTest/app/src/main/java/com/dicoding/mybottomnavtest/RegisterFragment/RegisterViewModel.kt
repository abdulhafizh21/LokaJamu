package com.dicoding.mybottomnavtest.RegisterFragment

import androidx.lifecycle.ViewModel

class RegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}